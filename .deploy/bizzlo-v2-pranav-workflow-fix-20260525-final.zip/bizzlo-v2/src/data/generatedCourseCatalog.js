export const generatedCourseCatalog = [];
